public class virus {
}
