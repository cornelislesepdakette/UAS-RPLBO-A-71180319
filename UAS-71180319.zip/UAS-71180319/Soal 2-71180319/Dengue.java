public class Dengue {
}
