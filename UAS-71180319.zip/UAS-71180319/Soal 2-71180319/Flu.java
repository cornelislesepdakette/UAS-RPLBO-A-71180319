public class Flu {
}
